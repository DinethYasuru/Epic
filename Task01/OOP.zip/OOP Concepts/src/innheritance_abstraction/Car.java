/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package innheritance_abstraction;

/**
 *
 * @author dinet
 */
public class Car {
  public String engine="V8";
  public int no_of_tyres= 4;
  
  
  public void engine_process(){
      System.out.println("Insert the key.");
      System.out.println("Ignite the coil.");
      System.out.println("Wait untill heater pulgs getting warmed.");
      System.out.println("Turn the key into the other side.");
      System.out.println("Engine starts.");
      System.out.println("Give the gas.");
      System.out.println("Hit the Cluch and release the hand breaks");
      System.out.println("Balance the cluch against the gas paddle");
      System.out.println("Use steering wheel to navigate");
      
      
  }
}
