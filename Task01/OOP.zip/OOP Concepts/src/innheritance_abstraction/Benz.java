/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package innheritance_abstraction;

/**
 *
 * @author dinet
 */
public class Benz extends Car{
    public static void main(String[] args) {    
        Benz benz = new Benz();
        System.out.println("A Benz car has "+ benz.no_of_tyres + "tyres");
        System.out.println("A Benz car has "+ benz.engine + "engine");
        
        
        //Abstraction
//        benz.engine_process();
    }
}
