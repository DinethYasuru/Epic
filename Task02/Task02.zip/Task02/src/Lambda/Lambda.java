package Lambda;

@FunctionalInterface
public interface Lambda {
    public int getAge();
}
